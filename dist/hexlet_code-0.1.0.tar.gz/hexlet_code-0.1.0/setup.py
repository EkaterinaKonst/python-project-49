# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['numexpr>=2.8.4,<3.0.0', 'prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gsd = brain_games.scripts.brain_gsd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Console games',
    'long_description': 'https://asciinema.org/a/kDjryKxRJxohphcnrA0p7VXF6   brain-even\n\nhttps://asciinema.org/a/8VCzQsdakqzNxagOyMTy0TyHp   brain-calc\n\nhttps://asciinema.org/a/A68PcdtRuxgCBtSvHEMu0bDwu   brain-gsd\n\nhttps://asciinema.org/a/NWHqKGHh8b7IxzjZK1loxynPA   brain-progression\n\nhttps://asciinema.org/a/RYjZ73EUNfN51JrjqEKyMh1Dn   brain-prime\n\n### Hexlet tests and linter status:\n[![Actions Status](https://github.com/EkaterinaKonst/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/EkaterinaKonst/python-project-49/actions)\n\n<a href="https://codeclimate.com/github/EkaterinaKonst/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/856a67b71015f5e578af/maintainability" /></a>\n',
    'author': 'Ekaterina Konstantinova',
    'author_email': 'feldsher2812@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/EkaterinaKonst/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
