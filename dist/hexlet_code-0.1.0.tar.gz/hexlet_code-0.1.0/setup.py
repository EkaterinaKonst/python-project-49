# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['numexpr>=2.8.4,<3.0.0', 'prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Console games',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/EkaterinaKonst/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/EkaterinaKonst/python-project-49/actions)\n\n<a href="https://codeclimate.com/github/EkaterinaKonst/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/856a67b71015f5e578af/maintainability" /></a>\n\n###Description\nThis project is a small entartainment package of 5 console mathematical games. You have to give 3 correct answers for each quiz, wrong answer terminates game.\n\n#####brain-even\nGuess whether the shown number is even or not.\n\n#####brain-calc\nGuess the result of simple mathematic expression.\n\n#####brain-gcd\nGuess the greatest common divisor of two given numbers.\n\n#####brain-progression\nGuess the missing number in given progression.\n\n#####brain-prime\nGuess whether the given number is prime or not.\n\n###Minimum requirements\npython3.9\n\n###Installation guide\nTo install the package for an end-user\n\nExecute:\n\npython3 -m pip install --user dist/*.whl\n\nIf you would like to install it as a developer\nTo install all dependencies execute:\n\nmake install\n\nTo build a package execute:\n\nmake build\n\nTo install the package execute:\n\nmake package-install\n\n###Scripts demo\n\nhttps://asciinema.org/a/kDjryKxRJxohphcnrA0p7VXF6   brain-even\n\nhttps://asciinema.org/a/8VCzQsdakqzNxagOyMTy0TyHp   brain-calc\n\nhttps://asciinema.org/a/A68PcdtRuxgCBtSvHEMu0bDwu   brain-gsd\n\nhttps://asciinema.org/a/NWHqKGHh8b7IxzjZK1loxynPA   brain-progression\n\nhttps://asciinema.org/a/RYjZ73EUNfN51JrjqEKyMh1Dn   brain-prime\n\n',
    'author': 'Ekaterina Konstantinova',
    'author_email': 'feldsher2812@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/EkaterinaKonst/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
