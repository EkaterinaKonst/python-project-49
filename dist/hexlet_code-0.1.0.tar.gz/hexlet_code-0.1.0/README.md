https://asciinema.org/a/kDjryKxRJxohphcnrA0p7VXF6

### Hexlet tests and linter status:
[![Actions Status](https://github.com/EkaterinaKonst/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/EkaterinaKonst/python-project-49/actions)

<a href="https://codeclimate.com/github/EkaterinaKonst/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/856a67b71015f5e578af/maintainability" /></a>
