https://asciinema.org/a/kDjryKxRJxohphcnrA0p7VXF6   brain-even

https://asciinema.org/a/8VCzQsdakqzNxagOyMTy0TyHp   brain-calc

https://asciinema.org/a/A68PcdtRuxgCBtSvHEMu0bDwu   brain-gsd

https://asciinema.org/a/NWHqKGHh8b7IxzjZK1loxynPA   brain-progression

https://asciinema.org/a/RYjZ73EUNfN51JrjqEKyMh1Dn   brain-prime

### Hexlet tests and linter status:
[![Actions Status](https://github.com/EkaterinaKonst/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/EkaterinaKonst/python-project-49/actions)

<a href="https://codeclimate.com/github/EkaterinaKonst/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/856a67b71015f5e578af/maintainability" /></a>
